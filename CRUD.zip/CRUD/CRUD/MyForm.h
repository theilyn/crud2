#pragma once

namespace CRUD {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	protected:
	private: System::Windows::Forms::Button^  descargar_btn;
	private: System::Windows::Forms::Button^  agg_btn;
	private: System::Windows::Forms::Button^  mod_btn;
	private: System::Windows::Forms::Button^  delete_btn;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->descargar_btn = (gcnew System::Windows::Forms::Button());
			this->agg_btn = (gcnew System::Windows::Forms::Button());
			this->mod_btn = (gcnew System::Windows::Forms::Button());
			this->delete_btn = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(25, 51);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(354, 184);
			this->dataGridView1->TabIndex = 0;
			// 
			// descargar_btn
			// 
			this->descargar_btn->Location = System::Drawing::Point(429, 105);
			this->descargar_btn->Name = L"descargar_btn";
			this->descargar_btn->Size = System::Drawing::Size(134, 23);
			this->descargar_btn->TabIndex = 1;
			this->descargar_btn->Text = L"Descargar";
			this->descargar_btn->UseVisualStyleBackColor = true;
			this->descargar_btn->Click += gcnew System::EventHandler(this, &MyForm::descargar_btn_Click);
			// 
			// agg_btn
			// 
			this->agg_btn->Location = System::Drawing::Point(429, 134);
			this->agg_btn->Name = L"agg_btn";
			this->agg_btn->Size = System::Drawing::Size(134, 23);
			this->agg_btn->TabIndex = 2;
			this->agg_btn->Text = L"Agregar";
			this->agg_btn->UseVisualStyleBackColor = true;
			this->agg_btn->Click += gcnew System::EventHandler(this, &MyForm::agg_btn_Click);
			// 
			// mod_btn
			// 
			this->mod_btn->Location = System::Drawing::Point(429, 163);
			this->mod_btn->Name = L"mod_btn";
			this->mod_btn->Size = System::Drawing::Size(134, 23);
			this->mod_btn->TabIndex = 3;
			this->mod_btn->Text = L"Modificar";
			this->mod_btn->UseVisualStyleBackColor = true;
			this->mod_btn->Click += gcnew System::EventHandler(this, &MyForm::mod_btn_Click);
			// 
			// delete_btn
			// 
			this->delete_btn->Location = System::Drawing::Point(429, 192);
			this->delete_btn->Name = L"delete_btn";
			this->delete_btn->Size = System::Drawing::Size(134, 23);
			this->delete_btn->TabIndex = 4;
			this->delete_btn->Text = L"Eliminar";
			this->delete_btn->UseVisualStyleBackColor = true;
			this->delete_btn->Click += gcnew System::EventHandler(this, &MyForm::delete_btn_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(576, 257);
			this->Controls->Add(this->delete_btn);
			this->Controls->Add(this->mod_btn);
			this->Controls->Add(this->agg_btn);
			this->Controls->Add(this->descargar_btn);
			this->Controls->Add(this->dataGridView1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void descargar_btn_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void agg_btn_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void mod_btn_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void delete_btn_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
